%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Caso 3: Modelo Económico 
clear all; close all; clc;

%% 1. Configuración
% Ajustado a 20 años según la gráfica
anios = 20; 
t = 0:anios;

% Condiciones iniciales: Empezamos en cero
x = zeros(2, anios + 1);

%% 2. Inicialización de parámetros 
a = 0.5;
b = 0.5;

% Definición de matrices A y B 
% Fila 1 (Consumo): c(t+1) = 0*c(t) + a*y(t)
% Fila 2 (GNP): y(t+1) = -b*c(t) + a(1+b)*y(t) + g(t+1)
A = [0,  a; 
    -b, a*(1+b)];

B = [0; 1];

%% 3. Simulación (Tiempo Discreto)
% El gasto g incrementa una unidad en el año 2 
g = zeros(1, anios + 1);
g(t >= 2) = 1; 

for k = 1:anios
    % Aplicamos la forma matricial: x(k+1) = A*x(k) + B*g(k+1)
    % Nota: k=1 en Matlab es t=0, por eso usamos k y k+1
    x(:, k+1) = A * x(:, k) + B * g(k+1);
end

%% 4. Gráficas
figure('Color', 'w', 'Name', 'Simulación Caso 3');

% Gráfica del GNP (y)
subplot(2,1,1);
plot(t, x(2,:), 'r-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
grid on;
ylabel('GNP y(t)');
title(['Simulación Económica (a=', num2str(a), ', b=', num2str(b), ')']);

% Gráfica del Consumo (c)
subplot(2,1,2);
plot(t, x(1,:), 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
grid on;
xlabel('Tiempo (Años)');
ylabel('Consumo c(t)');
legend('Consumo');

% Mostrar estabilidad en consola
fprintf('Estado estacionario alcanzado:\n');
fprintf('GNP final: %.2f\n', x(2,end));
fprintf('Consumo final: %.2f\n', x(1,end));