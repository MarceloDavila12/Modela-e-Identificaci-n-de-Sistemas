% Script: Modelos Ecológicos Corregido (Caso 1 y 2)
%% Materia: Modelado e Identificación de Sistemas - FIME
% Marelo Jose Davila Martinez  1895912

% Modelo competencia por recursos

clear all; close all; clc;

%% 1. Configuración
% 1 = Competencia por recursos, 2 = Predador-Presa 
caso_estudio = 1; 

tspan = [0 20]; % Tiempo de simulación 
x0 = [2; 2];    % Poblaciones iniciales [N1; N2] en millares

%% 2. Inicialización de parámetros
% Ponemos todo en 0 primero para que el ODE45 no marque error de variable no definida
L1=0; G1=0; d1=0; a1=0; L2=0; G2=0; d2=0; a2=0;

if caso_estudio == 1    % Aqui cambias "1 o 2"
    % CASO 1: COMPETENCIA
    L1 = 3; G1 = 1; d1 = 1; % Parámetros nominales 
    L2 = 2; G2 = 1; d2 = 1; 
    titulo_grafica = 'Caso 1: Competencia por Recursos';
else
    % CASO 2: PREDADOR-PRESA
    L1 = 1; G1 = 2; a1 = 1; % Predador (Lobos) 
    L2 = 2; G2 = 1; a2 = 1; % Presa (Alces)
    titulo_grafica = 'Caso 2: Predador - Presa';
end

%% 3. Simulación con ODE45
[t, x] = ode45(@(t, x) sistema_dinamico(t, x, caso_estudio, L1, G1, d1, a1, L2, G2, d2, a2), tspan, x0);

%% 4. Gráficas
figure('Color', 'w');
plot(t, x(:,1), 'r', 'LineWidth', 2); hold on;
plot(t, x(:,2), 'b', 'LineWidth', 2);
grid on; xlabel('Tiempo (años)'); ylabel('Población (millares)');
title(titulo_grafica);
legend('N1 (Especie 1)', 'N2 (Especie 2)');

% FUNCIÓN DEL SISTEMA
function dx = sistema_dinamico(t, x, selector, L1, G1, d1, a1, L2, G2, d2, a2)
    N1 = x(1); % Población Especie 1 
    N2 = x(2); % Población Especie 2 
    dx = zeros(2,1);
    
    if selector == 1
        % Basado en (L-G)N - d(N1+N2)N
        dx(1) = (L1 - G1)*N1 - d1*(N1 + N2)*N1; % Ecuación 8 
        dx(2) = (L2 - G2)*N2 - d2*(N1 + N2)*N2; % Ecuación 8 
    else
        % Predador-Presa: 
        dx(1) = (L1 - G1)*N1 + a1*N1*N2; % El predador crece comiendo 
        dx(2) = (L2 - G2)*N2 - a2*N1*N2; % La presa muere al ser comida 
    end
end 