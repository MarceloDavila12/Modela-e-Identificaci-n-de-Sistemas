%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Modelo de Sistema de Flujo (Tanque)
clear all; close all; clc;

%% 1. Configuración
% Definimos el tiempo de simulación y las condiciones iniciales
tspan = [0 10]; % Tiempo de 0 a 10s 
x0_vacio = 0;   % Caso A: Empieza vacío 
x0_lleno = 2;   % Caso B: Empieza lleno 

%% 2. Inicialización de parámetros

A = 1;          % Área de sección transversal (m^2) 
C = 1;          % Representa a*sqrt(2g)
u = 1;          % Flujo de entrada constante

%% 3. Simulación con ODE45
% Resolvemos para ambos casos de condición inicial
[t1, h1] = ode45(@(t, x) tanque_dinamico(t, x, A, C, u), tspan, x0_vacio);
[t2, h2] = ode45(@(t, x) tanque_dinamico(t, x, A, C, u), tspan, x0_lleno);

%% 4. Gráficas
figure('Color', 'w');
plot(t1, h1, 'b-', 'LineWidth', 2); hold on; % Línea azul (vacío)
plot(t2, h2, 'r--', 'LineWidth', 2);        % Línea roja punteada (lleno)

grid on;
xlabel('Tiempo (s)');
ylabel('Nivel h (m)');
title('Solución Numérica del Sistema de Flujo');
legend('h(0) = 0', 'h(0) = 2');

%% --- FUNCIÓN DEL SISTEMA ---
function dx = tanque_dinamico(t, x, A, C, u)
    % x(1) es el nivel del tanque (h)
    % Implementación de la Ecuación 15 de la clase 
    
    % h_dot = (1/A)*u - (C/A)*sqrt(h)
    dx = -(C/A) * sqrt(x(1)) + (1/A) * u;
end