%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Caso 3: Modelo Económico 
clear all; close all; clc;

