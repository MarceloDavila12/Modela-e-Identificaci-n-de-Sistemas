%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez 1895912

% Problema 2 - Tanque de Nivel (Puntos 1 y 2)

clear all; close all; clc;

% 1. Parámetros del Sistema (
A = 1;          % Área del tanque
k = 1;          % Este es el valor de a*sqrt(2g)
u = 1;          % Entrada constante para los casos A y B
tspan = [0 10]; % Tiempo solicitado de 0 a 10 segundos

% 2. Definición de la Ecuación Diferencial (EDO)
% dh/dt = -(k/A)*sqrt(h) + (1/A)*u
% Aquí 'h' es nuestra variable de estado (el nivel)
tanque_ode = @(t, h) -(k/A)*sqrt(h) + (1/A)*u;

% 3. Punto 1 (Caso A): Condición Inicial h(0) = 0
[tA, hA] = ode45(tanque_ode, tspan, 0);

% 4. Punto 2 (Caso B): Condición Inicial h(0) = 2
% Usamos la misma ecuación pero empezamos en nivel 2
[tB, hB] = ode45(tanque_ode, tspan, 2);

% 5. Gráfica de Comparación
figure('Color', 'w', 'Name', 'Problema 2: Casos A y B');
plot(tA, hA, 'r', 'LineWidth', 2); hold on;
plot(tB, hB, 'b', 'LineWidth', 2);

% Formato de la gráfica
grid on;
xlabel('Tiempo (segundos)');
ylabel('Nivel del Tanque h(t)');
legend('Punto 1: h(0)=0 (Se llena)', 'Punto 2: h(0)=2 (Se vacía)');
title('Dinámica del Tanque de Nivel - FIME');

% Línea de equilibrio (opcional, para que veas dónde se estabiliza)
yline(1, '--k', 'Nivel de Equilibrio (h=1)');