%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez 1895912

% Problema 2 - Punto 3 (Entrada Variable u=1 y u=3)

clear all; close all; clc;

% 1. Parámetros del Sistema
A = 1; 
k = 1; % Valor de a*sqrt(2g) según tu libreta
tspan = [0 20]; % Tiempo de 0 a 20 segundos

% 2. Definición de la entrada u(t) variable
% u(t) = 1 si 0 <= t < 10
% u(t) = 3 si 10 <= t < 20
u_func = @(t) (t < 10) * 1 + (t >= 10) * 3;

% 3. Definición de la EDO
% dh/dt = (1/A)*u(t) - (k/A)*sqrt(h)
tanque_ode_c = @(t, h) (1/A)*u_func(t) - (k/A)*sqrt(h);

% 4. Simulación con h(0) = 0
[tC, hC] = ode45(tanque_ode_c, tspan, 0);

% 5. Gráfica de Resultados
figure('Color', 'w');
plot(tC, hC, 'm', 'LineWidth', 2); % Color magenta para variar
grid on;
xlabel('Tiempo (s)');
ylabel('Nivel h(t)');
title('Problema 2 - Caso C: Entrada Variable (u=1 y u=3)');
legend('Nivel del agua (h)');

% Cálculo de puntos de equilibrio analíticos para tu reporte
fprintf('Nivel de equilibrio cuando u=1: h = 1.00 m\n');
fprintf('Nivel de equilibrio cuando u=3: h = 9.00 m\n');