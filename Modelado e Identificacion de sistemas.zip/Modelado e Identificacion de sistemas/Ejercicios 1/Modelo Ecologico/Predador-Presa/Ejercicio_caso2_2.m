% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Problema 1 - Inciso B - Puntos 2 y 3 (Barrido Predador-Presa)

clear all; close all; clc;

% 1. Parámetros Nominales (
% Los valores nominales definidos
L1 = 1; g1 = 2; a1 = 1; % a1 corresponde a delta1
L2 = 2; g2 = 1; a2 = 1; % a2 corresponde a delta2

tspan = [0 20]; % Tiempo de simulación 

% 2. Definición del Modelo (Lotka-Volterra)
% dN1/dt = (L1 - (g1 - a1*N2)) * N1 -> (-1 + N2)*N1
% dN2/dt = (L2 - (g2 + a2*N1)) * N2 -> (1 - N1)*N2
sistema_pred_presa = @(t, x) [ (L1 - (g1 - a1*x(2))) * x(1); ...
                               (L2 - (g2 + a2*x(1))) * x(2) ];

% 3. Preparación de Ventanas de Gráficas
figure('Color', 'w', 'Name', 'Problema 1-B: Variación de Condiciones');

% Subplot para N1(t) - Predadores 
subplot(2,2,1); hold on; grid on;
title('N1(t) variando cond. iniciales');
xlabel('Tiempo (t)'); ylabel('Población N1');

% Subplot para N2(t) - Presas 
subplot(2,2,2); hold on; grid on;
title('N2(t) variando cond. iniciales');
xlabel('Tiempo (t)'); ylabel('Población N2');

% Subplot para Diagrama de Fase N1 vs N2 (Punto 3) 
subplot(2,2,[3,4]); hold on; grid on;
title('Diagrama de Fase N1 vs N2 (El Remolino)');
xlabel('Predadores (N1)'); ylabel('Presas (N2)');

% 4. Barrido de Condiciones Iniciales (Punto 2) 
% Variación de 1.5 a 3.5 con incrementos de 0.5 para N1 y N2
for n1_init = 1.5 : 0.5 : 3.5
    for n2_init = 1.5 : 0.5 : 3.5
        
        x0 = [n1_init; n2_init];
        [t, x] = ode45(sistema_pred_presa, tspan, x0);
        
        % Graficamos evoluciones temporales
        subplot(2,2,1); plot(t, x(:,1)); 
        subplot(2,2,2); plot(t, x(:,2));
        
        % Graficamos el Retrato de Fase (N1 vs N2)
        subplot(2,2,[3,4]); plot(x(:,1), x(:,2));
        
    end
end
