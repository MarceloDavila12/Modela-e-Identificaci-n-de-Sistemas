%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez 1895912

% Problema 1 - Inciso B - Punto 1 (Predador-Presa)

clear all; close all; clc;

% 1. Parámetros Nominales (Página 2 del PDF)
L1 = 1; g1 = 2; d1 = 1;
L2 = 2; g2 = 1; d2 = 1;

% Condiciones iniciales: N1(0) = 2, N2(0) = 1
x0 = [2; 2]; 

% Tiempo de simulación: 0 a 20
tspan = [0 20];

% 2. Definición del Modelo (Lotka-Volterra)
% Ecuaciones del PDF:
% dN1/dt = (L1 - (g1 - d1*N2)) * N1
% dN2/dt = (L2 - (g2 + d2*N1)) * N2
sistema_B = @(t, x) [ (L1 - (g1 - d1*x(2))) * x(1); ...
                      (L2 - (g2 + d2*x(1))) * x(2) ];

% 3. Resolución con ode45
[t, x] = ode45(sistema_B, tspan, x0);

% 4. Gráfica de Resultados
figure('Color', 'w');
plot(t, x(:,1), 'r', 'LineWidth', 2); hold on;
plot(t, x(:,2), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (t)');
ylabel('Población (N)');
legend('Especie 1 (N1)', 'Especie 2 (N2)');
title('Problema 1-B: Respuesta Temporal (Punto 1)');

% Valores finales para verificar
fprintf('Población final N1: %.4f\n', x(end,1));
fprintf('Población final N2: %.4f\n', x(end,2));