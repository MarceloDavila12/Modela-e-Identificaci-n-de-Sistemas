%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez 1895912

% Problema 1 - Inciso A - Punto 1

clear all; close all; clc;

% 1. Parámetros Nominales
L1 = 3; L2 = 2; 
g1 = 1; g2 = 1; 
d1 = 1; d2 = 1;

% 2. Configuración de la Simulación
% Condiciones iniciales: N1(0) = 0.1, N2(0) = 2
x0 = [0.1; 2]; 

% Tiempo de 0 a 10
tspan = [0 10];

% 3. Definición del Sistema (Modelo de Competencia)
% dN1/dt = (L1 - (g1 + d1*(N1 + N2))) * N1
% dN2/dt = (L2 - (g2 + d2*(N1 + N2))) * N2
sistema_comp = @(t, x) [ (L1 - (g1 + d1*(x(1) + x(2)))) * x(1); ...
                         (L2 - (g2 + d2*(x(1) + x(2)))) * x(2) ];

% 4. Ejecución del ode45
[t, x] = ode45(sistema_comp, tspan, x0);

% 5. Gráfica de Resultados
figure('Color', 'w');
plot(t, x(:,1), 'r', 'LineWidth', 2); hold on;
plot(t, x(:,2), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (t)');
ylabel('Población (N)');
legend('Especie 1 (N1)', 'Especie 2 (N2)');
title('Problema 1-A: Punto 1 (N1(0)=0.1, N2(0)=2)');

% Mostrar valores finales en consola para tu reporte
fprintf('Población final N1: %.4f\n', x(end,1));
fprintf('Población final N2: %.4f\n', x(end,2));
