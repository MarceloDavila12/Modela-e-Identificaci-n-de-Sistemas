%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Problema 1 - Inciso A - Punto 2 y 3

clear all; close all; clc;

% 1. Parámetros Nominales
L1 = 3; L2 = 2; 
g1 = 1; g2 = 1; 
d1 = 1; d2 = 1;

tspan = [0 10]; % Tiempo solicitado

% 2. Definición del Modelo (Competencia)
sistema_comp = @(t, x) [ (L1 - (g1 + d1*(x(1) + x(2)))) * x(1); ...
                         (L2 - (g2 + d2*(x(1) + x(2)))) * x(2) ];

% 3. Preparación de Gráficas
figure('Color', 'w', 'Name', 'Problema 1-A: Barrido de Condiciones');

% Subplot para N1(t)
subplot(2,2,1); hold on; grid on;
title('Evolución de N1(t)');
xlabel('Tiempo (t)'); ylabel('Población N1');

% Subplot para N2(t)
subplot(2,2,2); hold on; grid on;
title('Evolución de N2(t)');
xlabel('Tiempo (t)'); ylabel('Población N2');

% Subplot para Diagrama de Fase (Punto 3)
subplot(2,2,[3,4]); hold on; grid on;
title('Diagrama de Fase: N1 vs N2');
xlabel('Población N1'); ylabel('Población N2');

% 4. Barrido de Condiciones Iniciales (Lógica de simulación)
% N1(0) de 0.1 a 1.0 (incrementos de 0.1)
% N2(0) de 2 a 10 (incrementos de 1)

for n1_0 = 0.1 : 0.1 : 1.0
    for n2_0 = 2 : 1 : 10
        
        x0 = [n1_0; n2_0]; % Condición inicial actual
        [t, x] = ode45(sistema_comp, tspan, x0);
        
        % Graficamos en los subplots correspondientes
        subplot(2,2,1); plot(t, x(:,1), 'r'); 
        subplot(2,2,2); plot(t, x(:,2), 'b');
        subplot(2,2,[3,4]); plot(x(:,1), x(:,2), 'k');
        
    end
end