%% Materia: Modelado e Identificación de Sistemas - FIME
% Marcelo Jose Davila Martinez  1895912

% Problema 3: Modelo Económico de Samuelson (Completo)

clear all; close all; clc;

% 1. Parámetros Globales
a = 0.5;
b = 0.5;
pasos = 20;
t_eje = 1:pasos;

% Matrices de Estado (Ecuación 7 del PDF)
A = [0, a; ...
    -b, a*(1+b)];
B = [0; 1];

% 2. PUNTO 1: Gasto Público Constante (g = 1)
c1 = zeros(1, pasos);
y1 = zeros(1, pasos);
g1 = 1; 

for t = 1 : (pasos - 1)
    x_t = [c1(t); y1(t)];
    x_sig = A * x_t + B * g1;
    c1(t+1) = x_sig(1);
    y1(t+1) = x_sig(2);
end

% 3. PUNTO 2: Gasto Público Variable
% Suponiendo que g aumenta de 1 a 2 a la mitad del tiempo 
c2 = zeros(1, pasos);
y2 = zeros(1, pasos);

for t = 1 : (pasos - 1)
    % Definimos g variable: 1 en la primera mitad, 2 en la segunda
    if t < 10
        g_var = 1;
    else
        g_var = 2;
    end
    
    x_t = [c2(t); y2(t)];
    x_sig = A * x_t + B * g_var;
    c2(t+1) = x_sig(1);
    y2(t+1) = x_sig(2);
end

% 4. Gráficas de Comparación
figure('Color', 'w', 'Name', 'Problema 3: Análisis de Gasto');

% Gráfica de Consumo
subplot(2,1,1);
plot(t_eje, c1, 'b-o', 'LineWidth', 1.5); hold on;
plot(t_eje, c2, 'm--s', 'LineWidth', 1.5);
grid on; ylabel('Consumo c(t)');
legend('Gasto Constante (g=1)', 'Gasto Variable');
title('Impacto del Gasto Público en el Consumo y la Renta');

% Gráfica de Renta
subplot(2,1,2);
plot(t_eje, y1, 'r-o', 'LineWidth', 1.5); hold on;
plot(t_eje, y2, 'k--s', 'LineWidth', 1.5);
grid on; ylabel('Renta y(t)'); xlabel('Tiempo (t)');
legend('Gasto Constante (g=1)', 'Gasto Variable');