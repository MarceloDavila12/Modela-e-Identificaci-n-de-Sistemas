% --- CASO 3: ROBOT 2-DOF (OPERACIÓN NORMAL) ---
function robot_fime()
    tspan = [0 10]; 
    x0 = [0; 0; 0; 0]; % [q1, dq1, q2, dq2]
    
    % Simulación con ODE45 para la dinámica no lineal
    [t, x] = ode45(@robot_dynamics, tspan, x0);

    % Gráficas
    figure('Color', 'w');
    subplot(2,1,1);
    plot(t, rad2deg(x(:,1)), 'b', 'LineWidth', 2); hold on;
    plot(t, rad2deg(x(:,3)), 'g', 'LineWidth', 2);
    yline(90, '--r', 'Meta 90°');
    title('Caso 3: Seguimiento de Trayectoria (Robot 2-DOF)');
    ylabel('Ángulo (grados)'); grid on; legend('Eslabón 1', 'Eslabón 2');

    subplot(2,1,2);
    plot(t, x(:,2), 'b--', t, x(:,4), 'g--');
    title('Velocidades Angulares');
    ylabel('rad/s'); xlabel('Tiempo (s)'); grid on;
end

function dxdt = robot_dynamics(t, x)
    % Parámetros
    m1 = 1; m2 = 0.5; l1 = 1; l2 = 0.8; g = 9.81;
    q1 = x(1); dq1 = x(2); q2 = x(3); dq2 = x(4);
    
    % Matrices Simplificadas (Dinámica de Spong)
    M = [3+2*cos(q2), 1+cos(q2); 1+cos(q2), 1];
    C = [-2*sin(q2)*dq2, -sin(q2)*dq2; sin(q2)*dq1, 0];
    G = [g*cos(q1) + 0.5*g*cos(q1+q2); 0.5*g*cos(q1+q2)];
    
    % Control PD + Compensación de Gravedad
    q_des = [pi/2; pi/2];
    tau = [15; 15].*(q_des - [q1; q2]) - [10; 10].*[dq1; dq2] + G;
    
    % Espacio de Estados: qdd = M \ (tau - C*dq - G)
    qdd = M \ (tau - C*[dq1; dq2] - G);
    dxdt = [dq1; qdd(1); dq2; qdd(2)];
end