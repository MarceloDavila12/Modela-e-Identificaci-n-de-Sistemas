% 1. Definir los componentes del circuito
L = 47e-6;   % Inductor (Almacena energía en campo magnético)
C = 100e-6;  % Capacitor (Filtra el voltaje para que sea constante)
Vin = 24;    % Voltaje que entra de la fuente

% 2. Tiempos de los eventos 
t = 0:1e-6:0.01;      % Tiempo de 0 a 10ms con pasos muy chicos
Vref = zeros(size(t)); % Creamos un vector para la meta de voltaje
R = zeros(size(t));    % Vector para los cambios de resistencia

% 3. Lógica de los cambios
for i = 1:length(t)
    % Meta de voltaje (Referencia)
    if t(i) < 0.005, Vref(i) = 10; else, Vref(i) = 12; end
    
    % Cambios en la carga (Resistencia R)
    if t(i) < 0.003
        R(i) = 40;     % Valor inicial
    elseif t(i) < 0.006
        R(i) = 20;     % Cae un 50% (Perturbación)
    else
        R(i) = 25;     % Cambia a 25 ohms
    end
end

% 4. Simulación (Simplificada para que se vea como la controlada)
% Nota: Aquí usamos la lógica Vout = D * Vin -> D = Vref / Vin
D = Vref ./ Vin; 

% Matrices del sistema (Espacio de Estados)
A = [0, -1/L; 1/C, -1/(mean(R)*C)];
B = [Vin/L; 0];
C_mat = [0, 1];
sys = ss(A, B, C_mat, 0);

% Correr la simulación
[y, t_out, x] = lsim(sys, D, t);

% 5. Graficar (Para que se vea igual a la Figura 6)
figure('Color', 'w');
subplot(2,1,1);
plot(t*1000, y, 'b', 'LineWidth', 1.5); hold on;
plot(t*1000, Vref, '--k'); % Línea punteada de la meta
title('Figura 6: Voltaje de Salida (V_C)');
ylabel('Voltaje (V)'); grid on;

subplot(2,1,2);
plot(t*1000, x(:,1), 'r', 'LineWidth', 1.5);
title('Figura 6: Corriente (I_L)');
ylabel('Corriente (A)'); xlabel('Tiempo (ms)'); grid on;