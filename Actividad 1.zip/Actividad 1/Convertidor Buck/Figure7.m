% --- Simulación de Robustez ante Carga: Figura 7 ---
% Parámetros base
L = 47e-6; C = 100e-6; Vin = 24; 
Vref = 10; % Referencia constante para esta prueba

% Tiempos y valores de R 
t_cambio1 = 0.003; % R de 40 a 60
t_cambio2 = 0.006; % R de 60 a 25
t_final = 0.01;

% Función para generar el sistema dinámico
get_sys = @(R) ss([0, -1/L; 1/C, -1/(R*C)], [Vin/L; 0], [0, 1], 0);

% --- Simulación por tramos (Continuidad matemática) ---

% 1. R = 40 (0 a 3ms)
s1 = get_sys(40);
t1 = 0:1e-6:t_cambio1;
[y1, ~, x1] = lsim(s1, (Vref/Vin)*ones(size(t1)), t1, [0; 0]);

% 2. R = 60 (3ms a 6ms) - Carga más ligera
s2 = get_sys(60);
t2 = t_cambio1:1e-6:t_cambio2;
[y2, ~, x2] = lsim(s2, (Vref/Vin)*ones(size(t2)), t2, x1(end,:));

% 3. R = 25 (6ms a 10ms) - Carga más pesada
s3 = get_sys(25);
t3 = t_cambio2:1e-6:t_final;
[y3, ~, x3] = lsim(s3, (Vref/Vin)*ones(size(t3)), t3, x2(end,:));

% --- Unión de Datos y Graficación ---
t = [t1, t2(2:end), t3(2:end)];
y = [y1; y2(2:end); y3(2:end)];
iL = [x1(:,1); x2(2:end,1); x3(2:end,1)];

figure('Color', 'w');
subplot(2,1,1);
plot(t*1000, y, 'b', 'LineWidth', 2); grid on; hold on;
yline(Vref, '--r', 'V_{ref}');
title('Figura 7: Voltaje de Salida (v_C) - Robustez ante R');
ylabel('Voltaje (V)');

subplot(2,1,2);
plot(t*1000, iL, 'k', 'LineWidth', 2); grid on;
title('Figura 7: Corriente en el Inductor (i_L)');
ylabel('Corriente (A)'); xlabel('Tiempo (ms)');