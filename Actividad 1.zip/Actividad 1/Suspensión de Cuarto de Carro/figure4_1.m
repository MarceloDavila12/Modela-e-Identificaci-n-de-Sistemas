% --- CASO 2: SUSPENSIÓN DE CUARTO DE CARRO (COMPLETO) ---
% Parámetros físicos (Extraídos de la Tabla 4.1)
M = 400; m = 30; ks = 15000; Cs = 1120; kt = 310000; Ct = 3100;

% 1. Definición de la Matriz A (Dinámica del sistema)
A = [0, 1, 0, 0;
    -ks/M, -Cs/M, ks/M, Cs/M;
    0, 0, 0, 1;
    ks/m, Cs/m, -(ks+kt)/m, -(Cs+Ct)/m];

% 2. Definición de la Matriz B (Entrada del bache)
B = [0; 0; 0; kt/m]; 

% 3. Definición de la Matriz C (Nuestras 2 Salidas)
% y1 = [1 0 0 0] * x -> Desplazamiento de la carrocería (xs)
% y2 = [1 0 -1 0] * x -> Deflexión de la suspensión (xs - xus)
C_mat = [1, 0,  0, 0; 
         1, 0, -1, 0]; 

% 4. Definición de la Matriz D (Relación directa entrada-salida)
D_mat = [0; 0];

% Crear el sistema en espacio de estados
sys = ss(A, B, C_mat, D_mat);

% 5. Simulación (Tope de 10cm durante 4 segundos)
t = 0:0.01:4;
u = 0.1 * ones(size(t));
[y, t_out] = lsim(sys, u, t);

% 6. Graficación de Resultados
figure('Color', 'w', 'Name', 'Análisis de Suspensión');

subplot(2,1,1);
plot(t_out, y(:,1), 'b', 'LineWidth', 2); hold on;
yline(0.1, '--r', 'Nivel del bache');
title('Salida y_1: Desplazamiento de la Carrocería (xs)');
ylabel('Metros (m)'); grid on;

subplot(2,1,2);
plot(t_out, y(:,2), 'm', 'LineWidth', 2);
title('Salida y_2: Deflexión de la Suspensión (xs - xus)');
xlabel('Tiempo (s)'); ylabel('Metros (m)'); grid on;